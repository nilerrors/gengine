//
// Created by nilerrors on 2/28/24.
//

#include "gengine_utils.h"

using namespace gengine;

double gengine::degToRad(double deg)
{
	double pi = 3.14159265359;
	return (deg * (pi / 180));
}
