//
// Created by nilerrors on 2/28/24.
//

#include <cmath>
#include "utils.h"

using namespace gengine;

double gengine::degToRad(double deg)
{
    return (deg * (PI / 180));
}
